import React, { useState } from "react";
import { ActiveScreen } from "../types";
import {
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Twitter,
  Github,
  Facebook,
  Instagram,
  Youtube,
  ArrowRight,
  Check
} from "lucide-react";

interface AppFooterProps {
  setActiveScreen: (screen: ActiveScreen) => void;
  activeScreen: ActiveScreen;
}

export default function AppFooter({ setActiveScreen, activeScreen }: AppFooterProps) {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    setTimeout(() => {
      setSubscribed(false);
      setEmail("");
    }, 4000);
  };

  const socialLinks = [
    { icon: Linkedin, href: "https://linkedin.com", label: "LinkedIn" },
    { icon: Twitter, href: "https://twitter.com", label: "Twitter" },
    { icon: Github, href: "https://github.com", label: "GitHub" },
    { icon: Facebook, href: "https://facebook.com", label: "Facebook" },
    { icon: Instagram, href: "https://instagram.com", label: "Instagram" },
    { icon: Youtube, href: "https://youtube.com", label: "YouTube" }
  ];

  return (
    <footer id="app-global-footer" className="w-full bg-[#09090b] text-zinc-400 border-t border-[#1a1a1f] select-none text-left pt-16 pb-8 px-6 md:px-12 mt-12">
      <div className="max-w-7xl mx-auto">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-16">
          
          {/* Column 1: Brand details */}
          <div className="lg:col-span-4 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#F59E0B] flex items-center justify-center font-bold text-black text-lg shadow-lg shadow-amber-500/10">
                G
              </div>
              <span className="text-xl font-bold text-white tracking-tight">GoChat AI</span>
            </div>
            
            <p className="text-sm text-zinc-400 leading-relaxed max-w-sm">
              Next-generation AI platform for chat, image, video, and asset generation. Built for creators and enterprises.
            </p>

            <div className="space-y-3.5 pt-2">
              <div className="flex items-center gap-3 text-sm text-zinc-400">
                <Mail className="w-4 h-4 text-zinc-500" />
                <a href="mailto:hello@gochat.ai" className="hover:text-white transition">hello@gochat.ai</a>
              </div>
              <div className="flex items-center gap-3 text-sm text-zinc-400">
                <Phone className="w-4 h-4 text-zinc-500" />
                <a href="tel:+15550000000" className="hover:text-white transition">+1 (555) 000-0000</a>
              </div>
              <div className="flex items-center gap-3 text-sm text-zinc-400">
                <MapPin className="w-4 h-4 text-zinc-500" />
                <span>San Francisco, CA</span>
              </div>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="lg:col-span-2 space-y-5">
            <h5 className="text-[11px] font-bold text-white uppercase tracking-widest">
              Quick Links
            </h5>
            <div className="flex flex-col space-y-3">
              {[
                { id: "about", label: "About" },
                { id: "privacy", label: "Privacy Policy" },
                { id: "terms", label: "Terms of Service" },
                { id: "contact", label: "Contact" }
              ].map((link) => (
                <button
                  id={`footer-link-${link.id}`}
                  key={link.id}
                  onClick={() => setActiveScreen(link.id as ActiveScreen)}
                  className={`text-sm text-zinc-400 hover:text-white transition text-left ${
                    activeScreen === link.id ? "text-[#F59E0B] font-medium" : ""
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          {/* Column 3: Stay Updated */}
          <div className="lg:col-span-3 space-y-5">
            <h5 className="text-[11px] font-bold text-white uppercase tracking-widest">
              Stay Updated
            </h5>
            <p className="text-sm text-zinc-400">
              Get the latest AI features and updates.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-2.5">
              <div className="flex gap-2">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="flex-1 bg-[#121214] border border-[#242429] focus:border-[#F59E0B]/50 focus:outline-none rounded-lg px-3 py-2 text-sm text-white placeholder-zinc-600 transition"
                  disabled={subscribed}
                />
                <button
                  type="submit"
                  disabled={subscribed}
                  className="bg-[#F59E0B] hover:bg-amber-400 text-black rounded-lg px-4 flex items-center justify-center transition cursor-pointer"
                >
                  {subscribed ? <Check className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                </button>
              </div>
              {subscribed && (
                <p className="text-xs text-amber-500 font-medium">
                  Successfully subscribed to GoChat newsletter!
                </p>
              )}
            </form>
          </div>

          {/* Column 4: Follow Us */}
          <div className="lg:col-span-3 space-y-5">
            <h5 className="text-[11px] font-bold text-white uppercase tracking-widest">
              Follow Us
            </h5>
            <div className="flex flex-wrap gap-2.5">
              {socialLinks.map((social, idx) => {
                const IconComp = social.icon;
                return (
                  <a
                    key={idx}
                    href={social.href}
                    target="_blank"
                    rel="noreferrer"
                    className="w-10 h-10 rounded-lg bg-[#121214] border border-[#242429] flex items-center justify-center text-zinc-400 hover:text-white hover:border-[#F59E0B]/30 hover:bg-zinc-900 transition"
                    title={social.label}
                  >
                    <IconComp className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
          </div>

        </div>

        {/* Bottom copyright bar */}
        <div className="pt-8 border-t border-[#1a1a1f] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <span>© 2026 GoChat AI. All rights reserved.</span>
          <span className="text-zinc-500 hover:text-zinc-400 transition cursor-pointer">
            Powered by GoChat AI
          </span>
        </div>
      </div>
    </footer>
  );
}
